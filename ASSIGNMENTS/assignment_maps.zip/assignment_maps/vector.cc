#include <iostream>
#include <utility>  // for std::pair
#include <string>
#include <vector>

int main() {
	using word_data = std::pair<std::string, size_t>;
	std::vector<word_data> data;
	
	std::string word("");
	
	std::cin >> word;
		
	while (word != "stop") {
		word_data wd;
		wd.first = word;
		wd.second = word.length();
		data.push_back(wd);
		std::cin >> word;
	}
	
	std::cout << std::endl << "Words and length:\n";
	for (auto wd : data)
		std::cout << wd.first << ", " << wd.second << "\n";
}